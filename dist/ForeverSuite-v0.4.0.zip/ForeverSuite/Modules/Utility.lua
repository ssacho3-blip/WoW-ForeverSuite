-- Module: Modules/Utility.lua
-- Responsibility: Auto-repair (guild -> personal fallback), 12-item buyback-capped junk seller, /fs protect, /fs sell, /fs xp session XP/h tracker, fast loot, QoL CVars.
-- Dependencies: Core/Init.lua, Core/MoneyLedgerQueue.lua, Core/ProfileManager.lua, Core/ModuleManager.lua.
-- Public API: Utility (TryAutoRepair, TryAutoSellJunk, ManualSellBatch, HandleProtectCommand, CleanActionBarsNow, ResetSessionXP, SyncSessionXP, GetSessionXPStats, FormatXPCompactLine, HandleXPCommand).
-- Combat/Secret Safety: Zero ActionBar frame/CVar auto-touch; caps each batch at <=12 items without auto-looping; guards secret prices and XP values.
local _, ns = ...

local type = type
local pcall = pcall
local select = select
local tonumber = tonumber
local tostring = tostring
local table_sort = table.sort
local math_min = math.min
local math_max = math.max
local math_floor = math.floor
local string_format = string.format
local string_sub = string.sub
local string_lower = string.lower
local string_match = string.match

local NUM_TOTAL_BAGS = 4
local POOR_QUALITY = (_G.Enum and _G.Enum.ItemQuality and _G.Enum.ItemQuality.Poor) or 0
local BUYBACK_HARD_CAP = 12

local Utility = {
    title = "편의 및 상점 자동화 (Utility)",
    priority = "P1",
    description = "자동 수리(길드→개인), 회색템 판매(12개 한도·/fs sell·보호목록), 세션 XP/시간(/fs xp), 고속 루팅",
    yieldTo = { "Leatrix_Plus" },
    merchantOpen = false,
    qolApplied = false,
    lastResidualCount = 0,
    reusableSellQueue = {},
    reusableSellEntryPool = {},
    xpState = {
        initialized = false,
        startedAt = 0,
        lastLevel = 0,
        lastXP = 0,
        lastMaxXP = 0,
        sessionGained = 0,
        lastGain = 0,
        secretGap = false,
        pendingLevelUp = false,
        waitCount = 0,
    },
}

local function IsShiftBypassActive()
    return (_G.IsShiftKeyDown and _G.IsShiftKeyDown()) and true or false
end

function Utility:OnInitialize()
    self.merchantOpen = false
    self.qolApplied = false
    self.lastResidualCount = 0
    ns.WipeTable(self.reusableSellQueue)
    ns.WipeTable(self.reusableSellEntryPool)
    self.xpState.initialized = false
    self.xpState.startedAt = 0
    self.xpState.lastLevel = 0
    self.xpState.lastXP = 0
    self.xpState.lastMaxXP = 0
    self.xpState.sessionGained = 0
    self.xpState.lastGain = 0
    self.xpState.secretGap = false
    self.xpState.pendingLevelUp = false
    self.xpState.waitCount = 0
end

function Utility:RevertExtraActionBarsIfNeeded(markFinal)
    if not (ns.ProfileManager and ns.ProfileManager:CanWrite()) then
        return false
    end
    local acct = ns.ProfileManager.runtimeAccount
    local charTbl = ns.ProfileManager.runtimeChar
    local utilTbl = (type(acct) == "table" and type(acct.utility) == "table") and acct.utility or nil
    if utilTbl then
        utilTbl.extraActionBars = nil
        utilTbl.extraActionBarMode = nil
        if markFinal ~= false then
            utilTbl._extraBarsRollback20261106 = true
            utilTbl._extraBarsRollback20261107 = true
        end
    end
    if markFinal ~= false and type(charTbl) == "table" then
        charTbl._extraBarsRollback20261106 = true
        charTbl._extraBarsRollback20261107 = true
    end
    return true
end

function Utility:CleanActionBarsNow()
    if ns.InCombat() then
        ns.Warn("전투 중에는 스킬창 설정을 변경할 수 없습니다. 전투 종료 후 실행해 주세요.")
        return false
    end
    self:RevertExtraActionBarsIfNeeded(true)
    local okAlways = ns.SafeSetCVar("alwaysShowActionBars", "1")
    local okToggles = false
    if type(_G.SetActionBarToggles) == "function" then
        okToggles = pcall(_G.SetActionBarToggles, false, false, false, false, false, false, false, false) and true or false
    end
    if not (okAlways and okToggles) then
        ns.Warn("스킬창 설정 API 호출에 실패하여 표시 해제를 확정할 수 없습니다.")
        return false
    end
    ns.Print("추가 스킬창 표시 해제 완료. 전투 중 오염 방지를 위해 /reload 를 한 번 실행해 주세요.")
    return true
end

local function IsUtilityModuleActive()
    if not ns.ModuleManager or type(ns.ModuleManager.GetModule) ~= "function" then
        return false
    end
    local rec = ns.ModuleManager:GetModule("Utility")
    local enabledState = (ns.ModuleManager.STATES and ns.ModuleManager.STATES.ENABLED) or "ENABLED"
    return rec ~= nil and rec.state == enabledState
end

function Utility:ApplyQoLCVars()
    local applied = false
    ns.CombatQueue:RunOrDefer("utility:qolCVars", function()
        if not IsUtilityModuleActive()
            or not ns.ProfileManager:CanWrite()
            or not ns.ProfileManager:Get("utility", "applyQoLCVars") then
            return
        end
        applied = ns.ProfileManager:ApplyTemporaryCVar("countdownForCooldowns", "1") and true or false
        self.qolApplied = applied
    end)
    return applied
end

function Utility:RestoreQoLCVars()
    local ok = false
    ns.CombatQueue:RunOrDefer("utility:qolCVars", function()
        if not ns.ProfileManager:CanWrite() then
            return
        end
        local pending = ns.ProfileManager.accountDB and ns.ProfileManager.accountDB.pendingCVarRestores
        local hadPending = type(pending) == "table" and pending["countdownForCooldowns"] ~= nil
        local restored = ns.ProfileManager:RestoreTemporaryCVar("countdownForCooldowns")
        if restored or not hadPending then
            self.qolApplied = false
            ok = true
        end
    end)
    return ok
end

function Utility:HandleProtectCommand(rawArg)
    local clean = ns.IsSecret(rawArg) and "" or tostring(rawArg or "")
    local trimmed = string_match(clean, "^%s*(.-)%s*$") or ""
    local sub = string_lower(trimmed)

    if trimmed == "" or sub == "list" then
        local ids = ns.ProfileManager:GetProtectedItemIDs()
        table_sort(ids)
        if #ids == 0 then
            ns.Print("등록된 판매 보호 아이템이 없습니다. (사용법: /fs protect <아이템링크 | 아이템ID | list>)")
            return true
        end
        local summary = "판매 보호 목록 (" .. tostring(#ids) .. "종): "
        for i = 1, #ids do
            local id = ids[i]
            local label = "#" .. tostring(id)
            if C_Item and C_Item.GetItemInfo then
                local name, link = C_Item.GetItemInfo(id)
                if type(link) == "string" and not ns.IsSecret(link) and link ~= "" then
                    label = link
                elseif type(name) == "string" and not ns.IsSecret(name) and name ~= "" then
                    label = name .. "(#" .. tostring(id) .. ")"
                end
            end
            summary = summary .. ((i > 1) and ", " or "") .. label
        end
        ns.Print(summary)
        return true
    end

    local parsedStr = string_match(trimmed, "|Hitem:(%d+)") or string_match(trimmed, "^(%d+)$")
    local itemID = parsedStr and tonumber(parsedStr) or nil
    if not itemID or itemID <= 0 then
        ns.Warn("사용법: /fs protect <아이템링크 | 아이템ID | list>")
        return false
    end
    itemID = math_floor(itemID)

    if not ns.ProfileManager:CanWrite() then
        ns.Warn("읽기 전용 프로필(미래 스키마)에서는 판매 보호 목록을 변경할 수 없습니다.")
        return false
    end

    local nextProtected = not ns.ProfileManager:IsProtectedItem(itemID)
    ns.ProfileManager:SetProtectedItem(itemID, nextProtected)
    local itemLabel = "#" .. tostring(itemID)
    if C_Item and C_Item.GetItemInfo then
        local _, link = C_Item.GetItemInfo(itemID)
        if type(link) == "string" and not ns.IsSecret(link) and link ~= "" then
            itemLabel = link
        end
    end
    ns.Print(itemLabel .. " → " .. (nextProtected and "[판매 보호 등록됨]" or "[판매 보호 해제됨]"))
    return true
end

function Utility:TryAutoRepair()
    if ns.IsFeatureYielded("repair") or not ns.ProfileManager:Get("utility", "autoRepair") then
        return
    end
    if not (_G.CanMerchantRepair and _G.CanMerchantRepair()) then
        return
    end
    if not _G.GetRepairAllCost or not _G.RepairAllItems then
        return
    end

    local repairCost, canRepair = _G.GetRepairAllCost()
    if not canRepair or type(repairCost) ~= "number" or ns.IsSecret(repairCost) or repairCost <= 0 then
        return
    end

    if ns.ProfileManager:Get("utility", "useGuildRepair") and _G.IsInGuild and _G.IsInGuild() then
        if _G.CanGuildBankRepair and _G.CanGuildBankRepair() then
            local rawWithdraw = _G.GetGuildBankWithdrawMoney and _G.GetGuildBankWithdrawMoney() or 0
            local rawFunds = _G.GetGuildBankMoney and _G.GetGuildBankMoney() or repairCost
            if type(rawWithdraw) == "number" and not ns.IsSecret(rawWithdraw) and type(rawFunds) == "number" and not ns.IsSecret(rawFunds) then
                if (rawWithdraw == -1 or rawWithdraw >= repairCost) and rawFunds >= repairCost then
                    _G.RepairAllItems(true)
                    ns.Print("길드 자금으로 장비 수리 완료 (" .. ns.FormatMoney(repairCost) .. ")")
                    return
                end
            end
        end
    end

    local myMoney = _G.GetMoney and _G.GetMoney() or 0
    if type(myMoney) == "number" and not ns.IsSecret(myMoney) and myMoney >= repairCost then
        ns._fsRepairArmedAt = ns.GetNow()
        ns.SetPendingMoneyReason("REPAIR", 1.5, -1, -repairCost)
        _G.RepairAllItems(false)
        ns._fsRepairArmedAt = nil
        ns.Print("개인 골드로 장비 수리 완료 (" .. ns.FormatMoney(repairCost) .. ")")
    else
        ns.Warn("골드가 부족하여 자동 수리를 건너뜁니다 (필요: " .. ns.FormatMoney(repairCost) .. ")")
    end
end

function Utility:SellJunkBatch(isManual)
    if not (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo and C_Container.UseContainerItem) then
        return 0
    end
    local configuredCap = tonumber(ns.ProfileManager:Get("utility", "maxSellBatch")) or BUYBACK_HARD_CAP
    local batchLimit = math_min(BUYBACK_HARD_CAP, configuredCap > 0 and configuredCap or BUYBACK_HARD_CAP)

    local queue = ns.WipeTable(self.reusableSellQueue)
    local totalEligible = 0

    for bag = 0, NUM_TOTAL_BAGS do
        local numSlots = C_Container.GetContainerNumSlots(bag) or 0
        if type(numSlots) == "number" and not ns.IsSecret(numSlots) then
            for slot = 1, numSlots do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if type(info) == "table"
                    and not ns.IsSecret(info.quality)
                    and info.quality == POOR_QUALITY
                    and not info.isLocked
                    and not info.hasNoValue
                    and not info.isRefundable
                then
                    local itemID = info.itemID
                    if itemID and not ns.IsSecret(itemID) and not ns.ProfileManager:IsProtectedItem(itemID) then
                        local rawSell = (C_Item and C_Item.GetItemInfo) and select(11, C_Item.GetItemInfo(itemID)) or nil
                        local sellPrice = (type(rawSell) == "number" and not ns.IsSecret(rawSell)) and rawSell or 0
                        if sellPrice > 0 then
                            totalEligible = totalEligible + 1
                            if #queue < batchLimit then
                                local rawStack = info.stackCount
                                local stackCount = (type(rawStack) == "number" and not ns.IsSecret(rawStack)) and rawStack or 1
                                local nextIdx = #queue + 1
                                local entry = self.reusableSellEntryPool[nextIdx]
                                if not entry then
                                    entry = {}
                                    self.reusableSellEntryPool[nextIdx] = entry
                                end
                                entry.bag = bag
                                entry.slot = slot
                                entry.itemID = itemID
                                entry.expected = sellPrice * stackCount
                                queue[nextIdx] = entry
                            end
                        end
                    end
                end
            end
        end
    end

    local soldCount = 0
    local expectedCopper = 0
    for i = 1, #queue do
        if not self.merchantOpen or (not isManual and IsShiftBypassActive()) then
            break
        end
        local entry = queue[i]
        local liveInfo = C_Container.GetContainerItemInfo(entry.bag, entry.slot)
        if type(liveInfo) == "table"
            and not liveInfo.isLocked
            and not liveInfo.hasNoValue
            and not liveInfo.isRefundable
            and not ns.IsSecret(liveInfo.itemID)
            and liveInfo.itemID == entry.itemID
            and not ns.ProfileManager:IsProtectedItem(liveInfo.itemID)
            and not ns.IsSecret(liveInfo.quality)
            and liveInfo.quality == POOR_QUALITY
        then
            ns._fsSellArmedAt = ns.GetNow()
            ns.SetPendingMoneyReason("VENDOR_SELL", 1.5, 1, entry.expected)
            C_Container.UseContainerItem(entry.bag, entry.slot)
            ns._fsSellArmedAt = nil
            soldCount = soldCount + 1
            expectedCopper = expectedCopper + entry.expected
        end
    end

    local remaining = math_max(0, totalEligible - soldCount)
    self.lastResidualCount = remaining
    if soldCount > 0 then
        local baseMsg = "회색 잡템 " .. tostring(soldCount) .. "칸 판매 요청 (예상 수익: " .. ns.FormatMoney(expectedCopper) .. ", 1회 안전 한도 " .. tostring(batchLimit) .. "칸)"
        if remaining > 0 then
            baseMsg = baseMsg .. " | 잔여 " .. tostring(remaining) .. "칸 — 추가 판매: /fs sell"
        end
        ns.Print(baseMsg)
    elseif isManual then
        ns.Print("판매 가능한 회색 잡템이 없습니다.")
    end
    return soldCount
end

function Utility:TryAutoSellJunk()
    if ns.IsFeatureYielded("sell") or not ns.ProfileManager:Get("utility", "autoSellJunk") then
        return 0
    end
    if not self.merchantOpen or IsShiftBypassActive() then
        return 0
    end
    return self:SellJunkBatch(false)
end

function Utility:ManualSellBatch()
    if ns.IsFeatureYielded("sell") then
        ns.Warn("상점 판매 기능이 외부 애드온에 양보(YIELDED)된 상태입니다.")
        return 0
    end
    if not self.merchantOpen then
        ns.Warn("상점 창이 열려 있을 때만 /fs sell 명령을 사용할 수 있습니다.")
        return 0
    end
    return self:SellJunkBatch(true)
end

function Utility:OnMerchantShow()
    self.merchantOpen = true
    if IsShiftBypassActive() then
        ns.Print("Shift 키 입력 감지: 상점 자동화를 일시 건너뜁니다.")
        return
    end
    self:TryAutoRepair()
    self:TryAutoSellJunk()
end

function Utility:OnMerchantClosed()
    self.merchantOpen = false
end

function Utility:OnLootReady()
    if ns.IsFeatureYielded("fastLoot") or not ns.ProfileManager:Get("utility", "fastAutoLoot") or ns.InCombat() or IsShiftBypassActive() then
        return
    end
    if not (_G.GetNumLootItems and _G.LootSlot) then
        return
    end
    local autoLootOn = (ns.SafeGetCVar("autoLootDefault") == "1")
    if _G.IsModifiedClick and _G.IsModifiedClick("AUTOLOOTTOGGLE") then
        autoLootOn = not autoLootOn
    end
    if not autoLootOn then
        return
    end
    local count = _G.GetNumLootItems()
    if type(count) ~= "number" or ns.IsSecret(count) or count <= 0 then
        return
    end
    for slot = count, 1, -1 do
        _G.LootSlot(slot)
    end
end

local function ReadCleanUnitXP()
    if type(_G.UnitXP) ~= "function" or type(_G.UnitXPMax) ~= "function" or type(_G.UnitLevel) ~= "function" then
        return nil, nil, nil, false
    end
    local okXP, xp = pcall(_G.UnitXP, "player")
    local okMax, maxXP = pcall(_G.UnitXPMax, "player")
    local okLvl, lvl = pcall(_G.UnitLevel, "player")
    if not (okXP and okMax and okLvl) then
        return nil, nil, nil, false
    end
    if type(xp) ~= "number" or ns.IsSecret(xp) or xp < 0
        or type(maxXP) ~= "number" or ns.IsSecret(maxXP) or maxXP < 0
        or type(lvl) ~= "number" or ns.IsSecret(lvl) or lvl < 1 then
        return nil, nil, nil, false
    end
    return math_floor(xp), math_floor(maxXP), math_floor(lvl), true
end

local function FormatDuration(seconds)
    if type(seconds) ~= "number" or ns.IsSecret(seconds) or seconds < 0 then
        return "—"
    end
    local sec = math_floor(seconds + 0.5)
    if sec < 60 then
        return string_format("%d초", sec)
    end
    if sec < 3600 then
        return string_format("%d분 %d초", math_floor(sec / 60), sec % 60)
    end
    return string_format("%d시간 %d분", math_floor(sec / 3600), math_floor((sec % 3600) / 60))
end

local function FormatNumberWithCommas(val)
    if type(val) ~= "number" or ns.IsSecret(val) then
        return "—"
    end
    local n = math_floor(val + 0.5)
    local sign = ""
    if n < 0 then
        sign = "-"
        n = -n
    end
    local s = tostring(n)
    local len = #s
    if len <= 3 then
        return sign .. s
    end
    local out = ""
    local rem = len % 3
    if rem > 0 then
        out = string_sub(s, 1, rem)
    end
    for i = rem + 1, len, 3 do
        if out ~= "" then
            out = out .. ","
        end
        out = out .. string_sub(s, i, i + 2)
    end
    return sign .. out
end

function Utility:ResetSessionXP()
    local s = self.xpState
    s.startedAt = ns.GetNow()
    s.sessionGained = 0
    s.lastGain = 0
    s.pendingLevelUp = false
    s.waitCount = 0
    local xp, maxXP, lvl, ok = ReadCleanUnitXP()
    if ok then
        s.initialized = true
        s.lastXP = xp
        s.lastMaxXP = maxXP
        s.lastLevel = lvl
        s.secretGap = false
    else
        s.initialized = false
        s.lastXP = 0
        s.lastMaxXP = 0
        s.lastLevel = 0
        s.secretGap = true
    end
    return s.initialized
end

function Utility:SyncSessionXP()
    local s = self.xpState
    local xp, maxXP, lvl, ok = ReadCleanUnitXP()
    if not ok then
        s.secretGap = true
        return 0
    end
    if not s.initialized then
        s.initialized = true
        s.startedAt = ns.GetNow()
        s.lastXP = xp
        s.lastMaxXP = maxXP
        s.lastLevel = lvl
        s.sessionGained = 0
        s.lastGain = 0
        s.secretGap = false
        s.pendingLevelUp = false
        s.waitCount = 0
        return 0
    end
    if s.secretGap then
        s.lastXP = xp
        s.lastMaxXP = maxXP
        s.lastLevel = lvl
        s.secretGap = false
        s.pendingLevelUp = false
        s.waitCount = 0
        return 0
    end

    local delta = 0
    if lvl > s.lastLevel then
        if s.pendingLevelUp then
            s.pendingLevelUp = false
            s.waitCount = 0
            delta = math_max(0, xp - s.lastXP)
        elseif lvl == s.lastLevel + 1 and xp >= s.lastXP and maxXP == s.lastMaxXP and s.waitCount < 1 then
            -- PLAYER_LEVEL_UP can fire once before UnitXP wraps to the new level; wait at most once.
            s.waitCount = s.waitCount + 1
            return 0
        else
            s.waitCount = 0
            delta = math_max(0, (s.lastMaxXP - s.lastXP) + xp)
        end
    elseif lvl == s.lastLevel then
        s.waitCount = 0
        if xp >= s.lastXP then
            delta = xp - s.lastXP
        else
            -- Classic/Forever PLAYER_XP_UPDATE can wrap XP before UnitLevel increments.
            delta = math_max(0, (s.lastMaxXP - s.lastXP) + xp)
            s.pendingLevelUp = true
        end
    else
        s.waitCount = 0
        s.pendingLevelUp = false
    end

    s.lastLevel = lvl
    s.lastXP = xp
    s.lastMaxXP = maxXP
    if delta > 0 then
        s.sessionGained = s.sessionGained + delta
        s.lastGain = delta
    end
    return delta
end

function Utility:GetSessionXPStats()
    local xp, maxXP, lvl, ok = ReadCleanUnitXP()
    if not ok then
        return nil
    end
    local s = self.xpState
    if not s.initialized then
        self:ResetSessionXP()
    end

    local maxLvl = nil
    if type(_G.GetMaxPlayerLevel) == "function" then
        local okMaxLvl, rawMaxLvl = pcall(_G.GetMaxPlayerLevel)
        if okMaxLvl and type(rawMaxLvl) == "number" and not ns.IsSecret(rawMaxLvl) and rawMaxLvl > 0 then
            maxLvl = rawMaxLvl
        end
    end
    local isMaxLevel = (maxXP <= 0) or (maxLvl ~= nil and lvl >= maxLvl)
    local elapsedSec = math_max(0, ns.GetNow() - s.startedAt)
    local remainingXP = isMaxLevel and 0 or math_max(0, maxXP - xp)
    local pct = (not isMaxLevel and maxXP > 0) and ((xp / maxXP) * 100) or 100
    local xpPerHour = (s.sessionGained > 0 and elapsedSec >= 1) and math_floor((s.sessionGained / elapsedSec) * 3600 + 0.5) or nil
    local etaSec = (not isMaxLevel and xpPerHour and xpPerHour > 0 and remainingXP > 0) and math_floor((remainingXP / xpPerHour) * 3600 + 0.5) or nil

    local restedXP = 0
    if type(_G.GetXPExhaustion) == "function" then
        local okRest, rawRest = pcall(_G.GetXPExhaustion)
        if okRest and type(rawRest) == "number" and not ns.IsSecret(rawRest) and rawRest > 0 then
            restedXP = math_floor(rawRest)
        end
    end

    return {
        level = lvl,
        xp = xp,
        maxXP = maxXP,
        remainingXP = remainingXP,
        pct = pct,
        isMaxLevel = isMaxLevel,
        sessionGained = s.sessionGained,
        elapsedSec = elapsedSec,
        xpPerHour = xpPerHour,
        etaSec = etaSec,
        restedXP = restedXP,
        secretGap = s.secretGap,
    }
end

function Utility:FormatXPCompactLine()
    local st = self:GetSessionXPStats()
    if not st or st.isMaxLevel then
        return nil
    end
    if not st.xpPerHour then
        return "|cff64748b—|r"
    end
    local etaText = st.etaSec and (" (예상 " .. FormatDuration(st.etaSec) .. ")") or ""
    return "|cff38bdf8" .. FormatNumberWithCommas(st.xpPerHour) .. "/h|r" .. etaText
end

function Utility:HandleXPCommand(rawArg)
    local clean = ns.IsSecret(rawArg) and "" or tostring(rawArg or "")
    local sub = string_lower(string_match(clean, "^%s*(%S*)") or "")
    if sub == "reset" or sub == "초기화" then
        self:ResetSessionXP()
        ns.Print("세션 XP 통계를 초기화했습니다.")
        return true
    end

    self:SyncSessionXP()
    local st = self:GetSessionXPStats()
    if not st then
        ns.Warn("현재 경험치 정보를 읽을 수 없습니다.")
        return false
    end
    if st.isMaxLevel then
        ns.Print(string_format("최고 레벨(Lv.%d) 상태입니다. (세션 경과: %s)", st.level, FormatDuration(st.elapsedSec)))
        return true
    end

    local rateStr = st.xpPerHour and (FormatNumberWithCommas(st.xpPerHour) .. " XP/시간") or "—"
    local etaStr = st.etaSec and FormatDuration(st.etaSec) or "—"
    local restedStr = (st.restedXP and st.restedXP > 0) and (" | 휴식 XP: " .. FormatNumberWithCommas(st.restedXP)) or ""
    ns.Print(string_format(
        "세션 XP: +%s XP (%s 경과) | 속도: %s | Lv.%d까지 %s XP (%.1f%%, 예상 %s)%s",
        FormatNumberWithCommas(st.sessionGained),
        FormatDuration(st.elapsedSec),
        rateStr,
        st.level + 1,
        FormatNumberWithCommas(st.remainingXP),
        st.pct,
        etaStr,
        restedStr
    ))
    return true
end

function Utility:OnXPUpdate()
    self:SyncSessionXP()
    local invRec = ns.ModuleManager and ns.ModuleManager:GetModule("Inventory")
    if invRec and invRec.state == "ENABLED" and invRec.definition and invRec.definition.RefreshHoveredGoldTooltip then
        invRec.definition:RefreshHoveredGoldTooltip()
    end
end

function Utility:OnPlayerEnteringWorld()
    self:RevertExtraActionBarsIfNeeded(true)
    if not self.xpState.initialized then
        self:ResetSessionXP()
    end
end

function Utility:OnEnable(ctx)
    self.ctx = ctx
    self:ApplyQoLCVars()
    self:RevertExtraActionBarsIfNeeded(true)
    if not self.xpState.initialized then
        self:ResetSessionXP()
    end
    ctx:RegisterEvent("PLAYER_ENTERING_WORLD", Utility.OnPlayerEnteringWorld)
    ctx:RegisterEvent("MERCHANT_SHOW", Utility.OnMerchantShow)
    ctx:RegisterEvent("MERCHANT_CLOSED", Utility.OnMerchantClosed)
    ctx:RegisterEvent("LOOT_READY", Utility.OnLootReady)
    ctx:RegisterEvent("PLAYER_XP_UPDATE", Utility.OnXPUpdate)
    ctx:RegisterEvent("PLAYER_LEVEL_UP", Utility.OnXPUpdate)
    ctx:AddCleanup(function()
        Utility:RestoreQoLCVars()
    end)
end

function Utility:OnDisable()
    self.ctx = nil
    self.merchantOpen = false
    self:RestoreQoLCVars()
    ns.WipeTable(self.reusableSellQueue)
    ns.WipeTable(self.reusableSellEntryPool)
end

ns.ModuleManager:Register("Utility", Utility)
