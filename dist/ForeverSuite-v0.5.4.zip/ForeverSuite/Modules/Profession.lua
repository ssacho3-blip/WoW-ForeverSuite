-- Module: Modules/Profession.lua
-- Responsibility: Combat-safe double-right-click fishing (dual release), crash-safe sound boost, gather yield tracker, and current-zone fishing target HUD.
-- Dependencies: Core/Init.lua, Core/ProfileManager.lua, Core/ModuleManager.lua, UI/FishingTargetModel.lua, UI/FishingTargetHud.lua.
-- Public API: Profession (IsFishingPoleEquipped, ClearFishingBindingSafe, ReconcilePendingLoot, PrintSessionYield, SyncFishingTargetHUD, HandleFishSlash).
-- Combat/Secret Safety: Defers SetOverrideBindingClick/ClearOverrideBindings via CombatQueue; preserves uncached item counts without data loss.
local _, ns = ...

local type = type
local pairs = pairs
local tonumber = tonumber
local string_find = string.find
local string_format = string.format
local string_lower = string.lower
local string_match = string.match

local MAINHAND_SLOT = 16
local FISHING_BASE_SPELL_ID = 7620
local TRADE_GOODS_CLASS_ID = 7

local Profession = {
    title = "전문기술 · 채집 · 낚시 편의 (Profession)",
    priority = "P1",
    description = "비전투 안전 더블우클릭 낚시, 현재 지역 낚시 대상어 HUD(/fs fish), 사운드 부스트, 채집물 집계",
    yieldTo = { "FishingBuddy" },
    active = false,
    secureBtn = nil,
    worldHooked = false,
    overrideActive = false,
    soundBoostActive = false,
    sfxBoostApplied = false,
    musicBoostApplied = false,
    lastRightClickAt = 0,
    sessionStartAt = 0,
    sessionTotalItems = 0,
    sessionGatherItems = 0,
    sessionGeneralItems = 0,
    sessionPendingItems = 0,
    sessionByItemID = {},
    pendingUncachedByItemID = {},
    clearBindingFn = nil,
}

local function ResolveFishingSpellName()
    if C_Spell and C_Spell.GetSpellInfo then
        local info = C_Spell.GetSpellInfo(FISHING_BASE_SPELL_ID)
        if type(info) == "table" and type(info.name) == "string" and info.name ~= "" then
            return info.name
        end
    end
    return "낚시"
end

function Profession:IsFishingPoleEquipped()
    if not _G.GetInventoryItemID then
        return false
    end
    local itemID = _G.GetInventoryItemID("player", MAINHAND_SLOT)
    if not itemID or ns.IsSecret(itemID) then
        return false
    end
    if C_Item and C_Item.GetItemInfo then
        local _, _, _, _, _, _, itemSubType, _, _, _, _, classID, subClassID = C_Item.GetItemInfo(itemID)
        if not ns.IsSecret(classID) and not ns.IsSecret(subClassID) and classID == 2 and subClassID == 20 then
            return true
        end
        if not ns.IsSecret(itemSubType) and type(itemSubType) == "string" then
            local low = string_lower(itemSubType)
            if string_find(low, "fishing", 1, true) or string_find(itemSubType, "낚싯대", 1, true) then
                return true
            end
        end
    end
    return false
end

function Profession:ClearFishingBindingSafe()
    if not self.overrideActive then
        return
    end
    if not self.secureBtn then
        self.overrideActive = false
        return
    end
    if ns.InCombat() then
        ns.CombatQueue:RunOrDefer("Profession:ClearFishingOverride", function()
            if Profession.overrideActive and Profession.secureBtn and _G.ClearOverrideBindings and not ns.InCombat() then
                _G.ClearOverrideBindings(Profession.secureBtn)
                Profession.overrideActive = false
            end
        end)
        return
    end
    if _G.ClearOverrideBindings then
        _G.ClearOverrideBindings(self.secureBtn)
    end
    self.overrideActive = false
end

function Profession:EnsureSecureFishingButton()
    if self.secureBtn or not _G.CreateFrame then
        return
    end
    ns.CombatQueue:RunOrDefer("Profession:InitFishingButton", function()
        if Profession.secureBtn then
            return
        end
        local btn = _G.ForeverSuiteFishingButton
        if type(btn) ~= "table" then
            btn = _G.CreateFrame("Button", "ForeverSuiteFishingButton", _G.UIParent, "SecureActionButtonTemplate")
        end
        if btn then
            if btn.Hide then
                btn:Hide()
            end
            if btn.RegisterForClicks then
                btn:RegisterForClicks("AnyUp", "AnyDown")
            end
            if btn.SetAttribute then
                btn:SetAttribute("type", "spell")
                btn:SetAttribute("spell", ResolveFishingSpellName())
            end
            if btn.SetScript then
                btn:SetScript("PostClick", function()
                    Profession:ClearFishingBindingSafe()
                end)
            end
            Profession.secureBtn = btn
        end
    end)
end

function Profession:OnWorldMouseDown(mouseButton)
    if not self.active or mouseButton ~= "RightButton" then
        return
    end
    if ns.IsFeatureYielded("fishing") or not ns.ProfileManager:Get("profession", "doubleClickFishing") then
        return
    end
    if ns.InCombat() or not self.secureBtn or not self:IsFishingPoleEquipped() then
        return
    end
    if type(_G.IsMouselooking) == "function" then
        local okMl, ml = pcall(_G.IsMouselooking)
        if not okMl or ns.IsSecret(ml) or ml == true then
            return
        end
    end
    if type(_G.UnitChannelInfo) == "function" then
        local okCh, ch = pcall(_G.UnitChannelInfo, "player")
        if not okCh or ns.IsSecret(ch) or ch ~= nil then
            return
        end
    end
    local lf = _G.LootFrame
    if ns.IsSecret(lf) then
        return
    end
    if type(lf) == "table" and type(lf.IsShown) == "function" then
        local okLf, shown = pcall(lf.IsShown, lf)
        if not okLf or ns.IsSecret(shown) or shown == true then
            return
        end
    end

    local now = ns.GetNow()
    local delta = now - self.lastRightClickAt
    if delta >= 0.05 and delta <= 0.40 then
        self.lastRightClickAt = 0
        if _G.SetOverrideBindingClick and not ns.InCombat() then
            _G.SetOverrideBindingClick(self.secureBtn, true, "BUTTON2", "ForeverSuiteFishingButton")
            self.overrideActive = true
            if C_Timer and C_Timer.After then
                C_Timer.After(0.05, self.clearBindingFn)
            end
        end
    else
        self.lastRightClickAt = now
    end
end

local function RestoreSingleSoundCVar(cvarName)
    local pending = ns.ProfileManager.accountDB and ns.ProfileManager.accountDB.pendingCVarRestores
    local hadPending = type(pending) == "table" and pending[cvarName] ~= nil
    if not hadPending then
        return true
    end
    return ns.ProfileManager:RestoreTemporaryCVar(cvarName) and true or false
end

local function RestoreSoundCVarsIfAllowed(self)
    if not ns.ProfileManager:CanWrite() then
        return false
    end
    local okSfx = RestoreSingleSoundCVar("Sound_SFXVolume")
    local okMus = RestoreSingleSoundCVar("Sound_MusicVolume")
    self.sfxBoostApplied = false
    self.musicBoostApplied = false
    self.soundBoostActive = false
    return okSfx and okMus
end

function Profession:RestoreFishingSoundBoost()
    local ok = false
    ns.CombatQueue:RunOrDefer("profession:soundBoost", function()
        ok = RestoreSoundCVarsIfAllowed(self)
    end)
    return ok
end

function Profession:SyncFishingSoundBoost()
    local ok = false
    ns.CombatQueue:RunOrDefer("profession:soundBoost", function()
        if not ns.ProfileManager:CanWrite() then
            return
        end
        local wantBoost = self.active
            and (not ns.IsFeatureYielded("fishing"))
            and ns.ProfileManager:Get("profession", "fishingSoundBoost")
            and self:IsFishingPoleEquipped()
        if wantBoost then
            if not self.sfxBoostApplied then
                self.sfxBoostApplied = ns.ProfileManager:ApplyTemporaryCVar("Sound_SFXVolume", "1.0") and true or false
            end
            if not self.musicBoostApplied then
                self.musicBoostApplied = ns.ProfileManager:ApplyTemporaryCVar("Sound_MusicVolume", "0.2") and true or false
            end
            self.soundBoostActive = (self.sfxBoostApplied or self.musicBoostApplied) and true or false
            ok = self.sfxBoostApplied and self.musicBoostApplied
        else
            local pending = ns.ProfileManager.accountDB and ns.ProfileManager.accountDB.pendingCVarRestores
            local hasAnyPending = type(pending) == "table" and (pending["Sound_SFXVolume"] ~= nil or pending["Sound_MusicVolume"] ~= nil)
            if self.soundBoostActive or hasAnyPending then
                ok = RestoreSoundCVarsIfAllowed(self)
            else
                ok = true
            end
        end
    end)
    return ok
end

function Profession:OnCombatEntering()
    self:ClearFishingBindingSafe()
end

function Profession:OnEquipmentChanged(_, slotID)
    if slotID == nil or slotID == MAINHAND_SLOT then
        self:SyncFishingSoundBoost()
        if not self:IsFishingPoleEquipped() and self.overrideActive then
            self:ClearFishingBindingSafe()
        end
        self:SyncFishingTargetHUD()
    end
end

local function ClassifyItemLootBucket(itemID)
    if not (C_Item and C_Item.GetItemInfo) then
        return nil
    end
    local itemName, _, _, _, _, itemType, itemSubType, _, _, _, _, classID = C_Item.GetItemInfo(itemID)
    if itemName == nil or ns.IsSecret(itemName) then
        return nil
    end
    if ns.IsSecret(classID) then
        return "general"
    end
    if type(classID) == "number" then
        return (classID == TRADE_GOODS_CLASS_ID) and "gather" or "general"
    end
    if type(itemType) == "string" and not ns.IsSecret(itemType) then
        if string_find(itemType, "직업용품", 1, true) or string_find(string_lower(itemType), "trade goods", 1, true) then
            return "gather"
        end
    end
    if type(itemSubType) == "string" and not ns.IsSecret(itemSubType) then
        if string_find(itemSubType, "물고기", 1, true) or string_find(string_lower(itemSubType), "fish", 1, true) then
            return "gather"
        end
    end
    return "general"
end

function Profession:ReconcilePendingLoot()
    for pid, pendingQty in pairs(self.pendingUncachedByItemID) do
        local bucket = ClassifyItemLootBucket(pid)
        if bucket == "gather" then
            self.sessionGatherItems = self.sessionGatherItems + pendingQty
            self.sessionPendingItems = self.sessionPendingItems - pendingQty
            self.pendingUncachedByItemID[pid] = nil
        elseif bucket == "general" then
            self.sessionGeneralItems = self.sessionGeneralItems + pendingQty
            self.sessionPendingItems = self.sessionPendingItems - pendingQty
            self.pendingUncachedByItemID[pid] = nil
        end
    end
end

function Profession:OnItemInfoReceived()
    if self.sessionPendingItems > 0 then
        self:ReconcilePendingLoot()
    end
end

function Profession:OnLootChatMsg(_, msg)
    if not ns.ProfileManager:Get("profession", "trackGatherYield") then
        return
    end
    if type(msg) ~= "string" or ns.IsSecret(msg) then
        return
    end
    -- Ignore party/raid members' loot lines
    if string_find(msg, "님이 아이템을 획득", 1, true) or string_find(msg, " receives loot:", 1, true) then
        return
    end
    local itemIDStr = string_match(msg, "|Hitem:(%d+)")
    local itemID = tonumber(itemIDStr)
    if not itemID then
        return
    end
    local qtyStr = string_match(msg, "|h|rx(%d+)") or string_match(msg, "|hx(%d+)") or string_match(msg, "x(%d+)%.?$")
    local qty = tonumber(qtyStr) or 1
    self.sessionByItemID[itemID] = (self.sessionByItemID[itemID] or 0) + qty
    self.sessionTotalItems = self.sessionTotalItems + qty

    local bucket = ClassifyItemLootBucket(itemID)
    if bucket == "gather" then
        self.sessionGatherItems = self.sessionGatherItems + qty
    elseif bucket == "general" then
        self.sessionGeneralItems = self.sessionGeneralItems + qty
    else
        self.pendingUncachedByItemID[itemID] = (self.pendingUncachedByItemID[itemID] or 0) + qty
        self.sessionPendingItems = self.sessionPendingItems + qty
    end
    self:ReconcilePendingLoot()
    if ns.FishingTargetHud and ns.FishingTargetHud.frame and ns.FishingTargetHud.frame.IsShown and ns.FishingTargetHud.frame:IsShown() then
        if ns.FishingTargetHud:HasTrackedItem(itemID) then
            self:SyncFishingTargetHUD()
        end
    end
end

function Profession:CheckGatheringTracking()
    if not ns.ProfileManager:Get("profession", "remindMissingTracking") or ns.InCombat() then
        return
    end
    if _G.IsResting and _G.IsResting() then
        return
    end
    if not (C_Minimap and C_Minimap.GetNumTrackingTypes and C_Minimap.GetTrackingInfo) then
        return
    end
    local rawCount = C_Minimap.GetNumTrackingTypes()
    if ns.IsSecret(rawCount) or type(rawCount) ~= "number" or rawCount <= 0 then
        return
    end
    local count = rawCount
    local hasGatherSkill = false
    local anyGatherActive = false

    for idx = 1, count do
        local info = C_Minimap.GetTrackingInfo(idx)
        local name, active, category
        if type(info) == "table" then
            name = info.name
            active = info.active
            category = info.type
        else
            name = info
        end
        if not ns.IsSecret(name)
            and not ns.IsSecret(active)
            and not ns.IsSecret(category)
            and type(name) == "string"
            and (category == "spell" or string_find(name, "찾기", 1, true) or string_find(string_lower(name), "find ", 1, true))
        then
            hasGatherSkill = true
            if active then
                anyGatherActive = true
                break
            end
        end
    end

    if hasGatherSkill and not anyGatherActive then
        ns.Print("채집 추적(광물/약초/물고기 찾기)이 꺼져 있습니다. 미니맵 추적을 확인하세요.")
    end
end

function Profession:SyncFishingTargetHUD()
    if not ns.FishingTargetHud then
        return nil
    end
    if not self.active then
        ns.FishingTargetHud:Hide()
        return nil
    end
    return ns.FishingTargetHud:Refresh({ poleEquipped = self:IsFishingPoleEquipped() })
end

function Profession:OnZoneChanged()
    self:CheckGatheringTracking()
    self:SyncFishingTargetHUD()
end

function Profession:HandleFishSlash(rawArg)
    local sub = string_lower(string_match(tostring(rawArg or ""), "^%s*(%S*)") or "")
    if sub == "" then
        if not ns.ProfileManager:Get("profession", "showFishingTargetHUD") then
            ns.Warn("낚시 대상어 HUD가 꺼져 있습니다. '/fs fish on' 또는 /fs 설정에서 활성화해 주세요.")
            return false
        end
        local pinned = ns.FishingTargetHud and ns.FishingTargetHud:TogglePin() or false
        local vm = ns.FishingTargetHud and ns.FishingTargetHud.lastViewModel or nil
        if pinned then
            ns.Print("낚시 대상어 HUD 고정 표시 (자동 전환: /fs fish auto)")
            if vm and ns.FishingTargetModel then
                ns.Print(ns.FishingTargetModel:FormatChatSummary(vm))
            end
        else
            ns.Print("낚시 대상어 HUD 자동 모드 복귀 (낚싯대 장착 시 자동 표시)")
        end
        return true
    elseif sub == "list" or sub == "show" then
        if ns.FishingTargetModel then
            local vm = ns.FishingTargetModel:BuildViewModel({ sessionByItemID = self.sessionByItemID })
            ns.Print(ns.FishingTargetModel:FormatChatSummary(vm))
        end
        return true
    elseif sub == "auto" then
        if ns.FishingTargetHud then
            ns.FishingTargetHud:SetAutoMode()
        end
        ns.Print("낚시 대상어 HUD 자동 모드: 낚싯대 장착 시 자동으로 표시됩니다.")
        return true
    elseif sub == "on" or sub == "off" then
        if not ns.ProfileManager:CanWrite() then
            ns.Warn("읽기 전용 프로필(미래 스키마)에서는 낚시 HUD 설정을 변경할 수 없습니다.")
            return false
        end
        local flag = (sub == "on")
        ns.ProfileManager:Set("profession", "showFishingTargetHUD", flag, "account")
        self:SyncFishingTargetHUD()
        ns.Print("현재 지역 낚시 대상어 HUD: " .. (flag and "활성화 (낚싯대 장착 또는 /fs fish)" or "비활성화"))
        return true
    elseif sub == "reset" then
        if not ns.FishingTargetHud then
            return false
        end
        local ok = ns.FishingTargetHud:ResetLayout()
        if not ok then
            ns.Warn("읽기 전용 프로필(미래 스키마)에서는 HUD 위치를 초기화할 수 없습니다.")
            return false
        end
        ns.Print("낚시 대상어 HUD 위치를 기본값으로 초기화했습니다.")
        return true
    end
    ns.Print("사용법: /fs fish [list | auto | on | off | reset]")
    return true
end

function Profession:PrintSessionYield()
    self:ReconcilePendingLoot()
    local elapsedSec = ns.GetNow() - self.sessionStartAt
    local perHourText = "—"
    if elapsedSec >= 30 and self.sessionGatherItems > 0 then
        local rate = (self.sessionGatherItems / elapsedSec) * 3600
        perHourText = string_format("%.1f개/시간", rate)
    end
    local distinct = 0
    for _ in pairs(self.sessionByItemID) do
        distinct = distinct + 1
    end
    ns.Print(string_format(
        "세션 집계 — 총 %d개 (%d종) | 채집물: %d개 | 일반 전리품: %d개 | 미캐시 대기: %d개 | 채집 속도: %s",
        self.sessionTotalItems,
        distinct,
        self.sessionGatherItems,
        self.sessionGeneralItems,
        self.sessionPendingItems,
        perHourText
    ))
end

function Profession:OnInitialize()
    self.sessionStartAt = ns.GetNow()
    self.sessionTotalItems = 0
    self.sessionGatherItems = 0
    self.sessionGeneralItems = 0
    self.sessionPendingItems = 0
    self.lastRightClickAt = 0
    ns.WipeTable(self.sessionByItemID)
    ns.WipeTable(self.pendingUncachedByItemID)
    self.clearBindingFn = function()
        Profession:ClearFishingBindingSafe()
    end
end

function Profession:OnEnable(ctx)
    self.active = true
    self.lastRightClickAt = 0
    if self.sessionStartAt <= 0 then
        self.sessionStartAt = ns.GetNow()
    end
    self:EnsureSecureFishingButton()

    if not self.worldHooked and _G.WorldFrame and _G.WorldFrame.HookScript then
        self.worldHooked = true
        _G.WorldFrame:HookScript("OnMouseDown", function(_, mouseButton)
            Profession:OnWorldMouseDown(mouseButton)
        end)
    end

    ctx:RegisterEvent("PLAYER_REGEN_DISABLED", Profession.OnCombatEntering)
    ctx:RegisterEvent("PLAYER_REGEN_ENABLED", Profession.SyncFishingSoundBoost)
    ctx:RegisterEvent("PLAYER_EQUIPMENT_CHANGED", Profession.OnEquipmentChanged)
    ctx:RegisterEvent("CHAT_MSG_LOOT", Profession.OnLootChatMsg)
    ctx:RegisterEvent("GET_ITEM_INFO_RECEIVED", Profession.OnItemInfoReceived)
    ctx:RegisterBucketEvent("PLAYER_ENTERING_WORLD", 0.50, Profession.SyncFishingTargetHUD)
    ctx:RegisterBucketEvent("ZONE_CHANGED_NEW_AREA", 0.35, Profession.OnZoneChanged)
    ctx:RegisterBucketEvent("ZONE_CHANGED", 0.35, Profession.SyncFishingTargetHUD)
    ctx:RegisterBucketEvent("SKILL_LINES_CHANGED", 0.50, Profession.SyncFishingTargetHUD)
    ctx:RegisterBucketEvent("QUEST_LOG_UPDATE", 0.50, Profession.SyncFishingTargetHUD)

    ctx:AddCleanup(function()
        Profession:ClearFishingBindingSafe()
        Profession:RestoreFishingSoundBoost()
        if ns.FishingTargetHud then
            ns.FishingTargetHud:Hide()
        end
    end)

    self:SyncFishingSoundBoost()
    self:SyncFishingTargetHUD()
end

function Profession:OnDisable()
    self.active = false
    self:ClearFishingBindingSafe()
    self:RestoreFishingSoundBoost()
    if ns.FishingTargetHud then
        ns.FishingTargetHud:Hide()
    end
end

ns.ModuleManager:Register("Profession", Profession)
